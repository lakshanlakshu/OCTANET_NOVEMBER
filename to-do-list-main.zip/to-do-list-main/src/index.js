import './style.css';
import './modules/crud.js';
import './modules/update.js';